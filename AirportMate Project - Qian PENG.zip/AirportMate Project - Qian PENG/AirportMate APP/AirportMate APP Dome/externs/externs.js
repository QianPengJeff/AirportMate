//@suppress {duplicate}
//function initYPM() {}
//function iScroll(){}
//function window(){}
//function Mustache(){}

//function getComputedStyle(){}
var getComputedStyle = window.getComputedStyle;

/*var module = 'undefined';

module.exports = 'undefined';
var exports = 'undefined';
var define = 'undefined';
//For backbone
var require = window.require = function(){};*/
var module = window.module;
module.exports = window.module.exports;
var exports = window.exports;

var require = window.require;
var define = undefined;

function TestFlight(){}

var Raphael = window.Raphael =function(){};
Raphael.getColor = function(){};

/*@return {!Raphael}*/
Raphael.path = function(){};

Raphael.attr = function(){};
Raphael.safari  = function(){};
Raphael.remove  = function(){};

var wink = window.wink ||{};

var iScroll= window.iScroll;
iScroll.disX;
iScroll.disY;
iScroll.moved;

//Rapheal
var DocumentTouch = window.DocumentTouch;

var createPopup = window.createPopup = function(){};

//var Backbone = window.Backbone = function(){};
var root = window ;

//var Backbone = window.Backbone;

//root.Backbone = function(){};
root.jQuery = function(){};
root._ = function(){};
root.$ = function(){};

//Framework7
//var Framework7 = window.Framework7;

//201501
root.jQuery0 = function(){};

var Q= window.Q;
var localStorage = window.localStorage;


//react:
var __REACT_DEVTOOLS_GLOBAL_HOOK__ = window.__REACT_DEVTOOLS_GLOBAL_HOOK__;
var global = window.global;


var cx=function(){};