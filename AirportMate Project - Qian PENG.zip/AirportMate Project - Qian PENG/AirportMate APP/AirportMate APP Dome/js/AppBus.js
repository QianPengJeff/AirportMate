var EventEmitter = require('./lib/events').EventEmitter;
var ChatConstants = require('./constants/ChatConstants');
var assign = require('./lib/object-assign');
var reactListenTo = require('./lib/react-listen-to');

var ActionTypes = ChatConstants.ActionTypes;


var AppBus = window.Backbone.View.extend({
    'el': "#main_views",
    template: "#main_screen_template",


    initialize: function() {
        var self = this;

        this['events'] = {
            'click .tab-link': this.clickMainTab,


            end: null
        };


    },

    initRender: function() {
        this.$el.html(iyOwner.Mustache.render0(
            $(this.template).html(),
            iyOwner.i18n.localizedString
        ));
    },

    clickMainTab: function(e) {
        var href;
        $("#main_tabbar").find('.tab-link').removeClass('active');
        $("#main_views").find('.view').removeClass('active');

        $(e.currentTarget).addClass("active");
        href = $(e.currentTarget).attr("href");
        $(href).addClass("active");
    },


    end: null
});

var appBus = new AppBus;

module.exports = appBus;
