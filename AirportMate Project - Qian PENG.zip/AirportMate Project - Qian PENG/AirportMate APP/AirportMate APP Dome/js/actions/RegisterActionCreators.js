/**
 * js/action/register.js
 */

"use strict"

var dispatcher = require('../dispatcher/ChatAppDispatcher');
var restapi = require("../shared/restapi")

module.exports = {
    register: function(user) {
        restapi
            .register
            .register
            .post({
                mobile: user.mobile,
                username: user.username,
                email: user.email,
                password: user.psw,
                password2: user.psw2,
                dosubmit: 'yes'
            })
            .done(function(res) {
                console.log(res)
            })
    },

    getMobileCode: function(mobile) {
        restapi
            .register
            .mobileVerCode
            .post(mobile)
            .done(function(res) {
                if (res.res == "OK") {
                    console.log("ok")
                    dispatcher.dispatch({
                        action: "getMobileCode"
                    })
                }
            })
    },

    verifyMobile: function(code) {
        restapi
            .register
            .mobileVer
            .post(code)
            .done(function(res) {
                if (res.res == "OK") {
                    dispatcher.dispatch({
                        action: "verifyMobile",
                        msg: 'mobieVerified'
                    })
                }
            })
    },

    isMobileExist: function(mobile) {
        if (mobile.length != 10) {
            return
        }

        restapi
            .register
            .mobileExist
            .post(mobile)
            .done(function(res) {
                if (res.res == "OK") {
                    dispatcher.dispatch({
                        action: "isMobileExist",
                        msg: 'mobileNotExist'
                    })
                }
            })
    },

    isUsernameExist: function(username) {
        restapi
            .register
            .usernameExist
            .post(username)
            .done(function(res) {
                if (res.res == "OK") {
                    dispatcher.dispatch({
                        action: "isUsernameExist",
                        msg: "usernameNotExist"
                    })
                }
            })
    },

    getCodeImage: function() {
        restapi
            .register
            .verImage
            .get()
    },

    verifyCode: function() {

    }
}
