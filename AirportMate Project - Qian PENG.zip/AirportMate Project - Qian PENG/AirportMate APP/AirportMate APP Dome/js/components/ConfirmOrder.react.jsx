/** @jsx React.DOM */
//var React = require('react');

var DateTimePicker = require('react-widgets').DateTimePicker;

var Multiselect = require('react-widgets').Multiselect;

var ConfirmOrder = React.createClass({
    getInitialState: function () {
        return {
            totalPrice: 0
        };
    },

    render: function () {
        return (
            <div className="confirmOrder">
                <TopNavbar />

                <div className="page-content">
                    <ConfirmOrderMainBody totalPrice={this.state.totalPrice}/>
                </div>
                <Toolbar totalPrice={this.state.totalPrice}/>
            </div>
        );
    }
});

var COMMENTS = ['comment1', 'comment2', 'comment3'];

var Comment = React.createClass({
    getInitialState: function () {
        var comments = this.props.comments;
        return {
            value: comments.slice(0, 1)
        };
    },

    _create: function (comment) {
        var comments = this.props.comments;
        var tag = {comment: comment, id: comments.length + 1}
        var value = this.state.value.concat(tag)
        comments.push(tag);
        this.setState({value: value})
    },

    _addComment: function (event) {
        this.setState({value: event.value});
    },

    render: function () {
        // create a tag object
        return (
            <Multiselect data={this.props.comments}
                         value={this.state.value}
                         textField="comment"
                         onCreate={this._create}
                         onChange={this._addComment}/>
        );
    }
});

var TopNavbar = React.createClass({
    render: function () {
        return (
            <div className="navbar">
                <div className="navbar-inner">
                    <div className="left">
                        <div data-icon="h" className="icon"></div>
                    </div>
                    <div className="center">Confirm Order</div>
                    <div className="right"></div>
                </div>
            </div>
        );
    }
});

var ConfirmOrderMainBody = React.createClass({
    getInitialState: function () {
        return {
            payMethod: "payOnline",
            timePickerOpened: false
        };
    },

    _handlePayMethodChange: function (event) {
        this.setState({payMethod: event.target.value});
    },

    _openTimePicker: function (event) {
        this.setState({timePickerOpened: "time"});
    },

    render: function () {
        return (
            <div>
                <div id="address" className="list-block">
                    <ul>
                        <li>
                            <a href="#" className="item-link">
                                <div className="item-content">
                                    <div className="item-media"><i className="icon icon"></i></div>
                                    <div className="item-inner">
                                        <div className="item-title">请填写地址</div>
                                    </div>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
                <div id="pay_method" className="list-block">
                    <ul>
                        <li>
                            <label className="label-radio item-content">
                                <input type="radio" name="payMethod" value="payOnline"
                                       onChange={this._handlePayMethodChange}/>

                                <div className="item-media">
                                    <i className="icon icon-form-radio"></i>
                                </div>
                                <div className="item-inner">
                                    <div className="item-title">Pay Online</div>
                                </div>
                            </label>
                        </li>
                        <li>
                            <label className="label-radio item-content">
                                <input type="radio" name="payMethod" value="payCash"
                                       onChange={this._handlePayMethodChange}/>

                                <div className="item-media">
                                    <i className="icon icon-form-radio"></i>
                                </div>
                                <div className="item-inner">
                                    <div className="item-title">Cash on Delivery</div>
                                </div>
                            </label>
                        </li>
                    </ul>
                </div>
                <p>Arriving Time</p>
                <DateTimePicker calendar={false}/>

                <p>Comment</p>
                <Comment comments={COMMENTS}/>

                <div id="totalPrice" className="list-block">
                    <ul>
                        <li className="item-content">
                            <div className="item-inner">
                                <div className="item-title">Total Price</div>
                                <div className="item-after">AUD ${this.props.totalPrice}</div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        );
    }
});

var Toolbar = React.createClass({
    render: function () {
        return (
            <div className="toolbar">
                <div className="toolbar-inner">
                    <a href="#" className="item-link item-content">
                        <div className="item-inner">
                            <div className="item-title">AUD ${this.props.totalPrice}</div>
                            <div className="item-after button button-fill color-green ripple-pink">Pay</div>
                        </div>
                    </a>
                </div>
            </div>
        );
    }
});

module.exports = ConfirmOrder;
