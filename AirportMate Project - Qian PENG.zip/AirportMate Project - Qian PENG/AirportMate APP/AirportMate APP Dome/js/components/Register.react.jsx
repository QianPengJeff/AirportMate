var RegisterActionCreators = require('../actions/RegisterActionCreators');

var RegisterStore = require('../stores/RegisterStore');

var reactListenTo = require('../lib/react-listen-to');

var RegisterForm = React.createClass ({

	mixins: [reactListenTo],

	getInitialState: function() {
	    return { status : "mobileUnchecked" }
	},

	_onChange: function() {
	    this.setState({
	    	status: RegisterStore.getStatus()
	    })  
	    console.log(this.state.status)
	},
	
	_register: function() {
		var user = {
			"mobile": this.refs.mobile.getDOMNode().value.trim(),
			"email": this.refs.email.getDOMNode().value.trim(),
			"username": this.refs.username.getDOMNode().value.trim(),
			"password": this.refs.password.getDOMNode().value.trim(),
			"password2": this.refs.password2.getDOMNode().value.trim()
		}
		if(user.mobile != "" && user.email != "" && user.username != "" && user.password != "" && user.password2 != "" && this.state.status == "verified"){
			RegisterActionCreators.register(user);
			this.refs.mobile.getDOMNode().value = "";
			this.refs.email.getDOMNode().value = "";
			this.refs.username.getDOMNode().value = "";
			this.refs.password2.getDOMNode().value = "";
			this.refs.password.getDOMNode().value = "";
		}else {
			alert("error!");
		}
		
	},

	_getVerificationCode: function() {
		if(this.state.status == "mobileChecked"){
			console.log("get code")
			var mobile = this.refs.mobile.getDOMNode().value.trim();
			if(mobile != ""){
				RegisterActionCreators.getVerificationCode(mobile);
			}else{
				alert("input your mobile number");
			}
		}
		
	},

	_verify: function() {
		var verification = this.refs.verification.getDOMNode().value.trim();
		if(verification != "") {
			RegisterActionCreators.verify(verification);
		}else{
			alert("input your verification code");
		}
	},

	componentDidMount: function() {
	    this.listenTo(RegisterStore, RegisterStore.storeEvent.CREATE, this._onChange);
	    this.listenTo(RegisterStore, RegisterStore.storeEvent.GET_VERIFICATION_CODE, this._onChange);
	    this.listenTo(RegisterStore, RegisterStore.storeEvent.VERIFY, this._onChange);
	    this.listenTo(RegisterStore, RegisterStore.storeEvent.CHECKMOBILEEXIST, this._onChange)
	},

	handleMobileChange: function(event){
		RegisterActionCreators.checkMobileExist(event.target.value)
	},

	render: function() {
		return(
			<div>
				<h3>Registeration</h3>
				<input type="text" placeholder="Mobile" ref="mobile" onChange={this.handleMobileChange} />
				<br />
				<br />
				<input type="text" placeholder="Verification code" ref="verification" />
				<button onClick = {this._getVerificationCode} ref="getVerificationCode">Get Verification Code</button>
				<input type="submit" value="verify code" onClick={this._verify} />
	            <br />
	            <br />
	            <input type="text" placeholder="Email" ref="email" />
	            <br />
	            <br />
	            <input type="text" placeholder="Username" ref="username" />
	            <br />
	            <br />
	            <input type="text" placeholder="Password" ref="password" />
	            <br />
	            <br />
	            <input type="text" placeholder="Confirmation" ref="password2" />
	            <br />
	            <br />
	            <input type="submit" value="Submit" onClick={this._register}/> 
	            <p>Status: {this.state.status}</p>
			</div>
		);		
	}
});

module.exports = RegisterForm;