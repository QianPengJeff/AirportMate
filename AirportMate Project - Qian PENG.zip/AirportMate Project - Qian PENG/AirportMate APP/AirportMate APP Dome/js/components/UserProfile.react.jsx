//var React = require('react');

var UserProfile = React.createClass({
    render: function() {
        return (
            <div>
                <input type="text" class="username" placeholder="Username" /><br />
                <input type="text" calss="email" placeholder="Email" /><br />
            </div>
        );
    }
});

module.exports = UserProfile;