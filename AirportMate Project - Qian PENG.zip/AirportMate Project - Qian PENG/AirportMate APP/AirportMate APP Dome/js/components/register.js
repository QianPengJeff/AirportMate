'use strict'

var action = require('../actions/RegisterActionCreators');
var registerStore = require('../stores/RegisterStore');
var Mustache = require('mustache')

var $ = require('jquery')

var ViewRegister = window.Backbone.View.extend({
    'el': '#viewRegister',
    template: '#registerTemplate',

    initialize: function() {
        this.events = {
            'blur #mobieCode': this.verifyMobileCode,
            'click #verifyMobileBtn': this.getMobileCode,
            'blur #username': this.isUsernameExist,
            'blur #mobile': this.isMobileExist
        }

        this.listenTo(registerStore, registerStore.events.username.exist.no, function() {
            console.log(e)
        })
    },

    render: function() {
        this.$el.html($(this.template).html())
    },

    // =====================================================
    // events
    isMobileExist: function(event) {
        console.log(event.target.value)
        action.isMobileExist(event.target.value)
    },

    getMobileCode: function(e) {
        action.getMobileCode($('#mobile').val())
    },

    verifyMobileCode: function(event) {
        action.verifyCode(event.target.value)
    },

    isUsernameExist: function(event) {
        action.isUsernameExist(event.target.value)
    },

    verifyMobile: function(event) {
        action.verifyMobile(event.target.value)
    },

    isPswSame: function(event) {
        if (event.target.value != this.state.psw) {
            this.setState({
                status: 'pswNotMatch'
            })
        } else {
            this.setState({
                status: 'pswMatch'
            })
        }
    }
})

// var RegisterForm = React.createClass({

//             getInitialState: function() {
//                 return {
//                     status: "mobileUnchecked"
//                 }
//             },

//             _onChange: function() {
//                 this.setState({
//                     status: RegisterStore.getStatus()
//                 })
//                 console.log(this.state.status)
//             },

//             _register: function() {
//                 var user = {
//                     "mobile": this.refs.mobile.getDOMNode().value.trim(),
//                     "email": this.refs.email.getDOMNode().value.trim(),
//                     "username": this.refs.username.getDOMNode().value.trim(),
//                     "password": this.refs.password.getDOMNode().value.trim(),
//                     "password2": this.refs.password2.getDOMNode().value.trim()
//                 }
//                 if (user.mobile != "" && user.email != "" && user.username != "" && user.password != "" && user.password2 != "" && this.state.status == "verified") {
//                     RegisterActionCreators.register(user);
//                     this.refs.mobile.getDOMNode().value = "";
//                     this.refs.email.getDOMNode().value = "";
//                     this.refs.username.getDOMNode().value = "";
//                     this.refs.password2.getDOMNode().value = "";
//                     this.refs.password.getDOMNode().value = "";
//                 } else {
//                     alert("error!");
//                 }

//             },

//             _getVerificationCode: function() {
//                 if (this.state.status == "mobileChecked") {
//                     console.log("get code")
//                     var mobile = this.refs.mobile.getDOMNode().value.trim();
//                     if (mobile != "") {
//                         RegisterActionCreators.getVerificationCode(mobile);
//                     } else {
//                         alert("input your mobile number");
//                     }
//                 }
//             },

//             _verify: function() {
//                 var verification = this.refs.verification.getDOMNode().value.trim();
//                 if (verification != "") {
//                     RegisterActionCreators.verify(verification);
//                 } else {
//                     alert("input your verification code");
//                 }
//             },

//             componentDidMount: function() {
//                 this.listenTo(RegisterStore, RegisterStore.storeEvent.CREATE, this._onChange);
//                 this.listenTo(RegisterStore, RegisterStore.storeEvent.GET_VERIFICATION_CODE, this._onChange);
//                 this.listenTo(RegisterStore, RegisterStore.storeEvent.VERIFY, this._onChange);
//                 this.listenTo(RegisterStore, RegisterStore.storeEvent.CHECKMOBILEEXIST, this._onChange)
//             },

//             handleMobileChange: function(event) {
//                 RegisterActionCreators.checkMobileExist(event.target.value)
//             });

module.exports = new ViewRegister();
