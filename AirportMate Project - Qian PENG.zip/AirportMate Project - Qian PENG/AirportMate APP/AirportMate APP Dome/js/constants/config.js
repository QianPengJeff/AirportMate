module.exports = {
	"host" : "http://iiyum.com.au:40080"
}