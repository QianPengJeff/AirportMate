
var MessageSection = require('./MessageSection.react');
//var React = require('react');
var ThreadSection = require('./ThreadSection.react');

var MainApp1 = React.createClass({



  componentDidMount: function() {
    $('#wrapper13').css('height', 200+'px');
    $('#wrapper23').css('height', 400+'px');

    //this._prodListScroll = new  window.iScroll('wrapper23');
    this._cateScroll = new window.iScroll('wrapper13');

  },

  render: function() {
    return (
      <div className="chatapp">
        <ThreadSection />
      </div>
    );
  }

});

module.exports = MainApp1;
