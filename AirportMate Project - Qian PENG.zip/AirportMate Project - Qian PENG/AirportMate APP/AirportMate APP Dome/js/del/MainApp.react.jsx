
var MessageSection = require('./MessageSection.react');
//var React = require('react');
var ThreadSection = require('./ThreadSection.react');

var MainApp = React.createClass({



  componentDidMount: function() {
    $('#wrapper13').css('height', 200+'px');
    $('#wrapper23').css('height', 200+'px');

    this._prodListScroll = new  window.iScroll('wrapper23');
    //this._cateScroll = new iyOwner.IScroll(iyOwner.IScrollSharp+'wrapper13');

  },

  render: function() {
    return (
      <div className="chatapp">
        <MessageSection />
      </div>
    );
  }

});

module.exports = MainApp;
