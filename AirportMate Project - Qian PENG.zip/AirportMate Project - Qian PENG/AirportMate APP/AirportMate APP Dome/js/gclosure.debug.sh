#cd /home/bliu/workspaces/www/iOS/prj/iiYumOwner/www/js.release

jsx app.jsx > app.js
jsx -x jsx components/ components/

java  -jar ~/ProgramFiles/ClosureCompiler/compiler.jar  --compilation_level  ADVANCED_OPTIMIZATIONS  --manage_closure_dependencies true  --externs ../externs/externs.js --externs ../externs/react_externs.js  --js app.js --js ChatExampleData.js --js lib/*.js --js components/*.js --js stores/*.js --js actions/*.js --js dispatcher/*.js --js utils/*.js --js constants/*.js --js flux/*.js   --debug true  --formatting=PRETTY_PRINT --warning_level VERBOSE  --process_common_js_modules --common_js_entry_module ./app.js  --create_source_map bundle.goog.js.map --source_map_format=V3   --js_output_file bundle.goog.js

#cat bundle.debugMap.js >> bundle.goog.js 

#--externs externs/externs.js --js react/lib/cx.js --externs externs/react_externs.js --transform_amd_modules --js react.js --js react-with-addons.js --js reactlib/cx.js 

#java -jar ~/ProgramFiles/ClosureCompiler/compiler.jar  --compilation_level  SIMPLE_OPTIMIZATIONS --js iyowner.all.js --externs externs/iyOwner.js --externs externs/jquery-1.9.js >iyowner.all.closure.js  --externs externs/underscore-1.5.1.js --externs externs/backbone-1.1.0-externs.js --third_party  --warning_level VERBOSE

#java -jar ~/ProgramFiles/ClosureCompiler/compiler.jar --compilation_level ADVANCED_OPTIMIZATIONS --process_jquery_primitives --js iyowner.all.js --externs externs/extern1.js --externs externs/jquery-1.5.2.js >iyowner.all.closure.js

#--warning_level VERBOSE --process_jquery_primitives

