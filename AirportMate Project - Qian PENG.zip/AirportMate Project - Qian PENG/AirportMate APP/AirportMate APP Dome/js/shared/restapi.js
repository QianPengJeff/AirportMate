/**
 * js/shared/restapi.js
 */

"use strict"

/**
 * [jquery node module]
 * @type {function}
 */
var $ = require("jquery")

var HOST = "http://iiyum.com.au:40080"
    //var HOST = "http://itisyum.com"

var url = {
    register: function(params) {
        return "{host}/member.php?act=reg".format({
            host: HOST
        })
    },

    isMobileExist: function(params) {
        return "{host}/index.php?m=member&act=ajax&op=check_mobile".format({
            host: HOST
        })
    },

    getMobileCode: function(params) {
        return "{host}/index.php?m=member&act=ajax&op=send_verify".format({
            host: HOST
        })
    },

    verifyMobileCode: function(params) {
        return "{host}/index.php?m=member&act=ajax&op=check_mobile_verify".format({
            host: HOST
        })
    },

    isUsernameExist: function(params) {
        return "{host}/index.php?m=member&act=ajax&op=check_username".format({
            host: HOST
        })
    },

    getCodeImage: function(params) {
        var random = Math.random().toFixed(2) * 1000
        return "{host}/index.php?m=index&act=seccode&x=618&x={random}".format({
            host: HOST,
            random: random
        })
    }


}

module.exports = {
    /**
     * 
     * @type {Object}
     */
    register: {
        register: {
            post: function(params) {
                return $.post(url.register(), params, null, 'json')
            }
        },

        mobileVerCode: {
            post: function(mobile) {
                return $.post(url.getMobileCode(), {
                    mobile: mobile,
                    in_ajax: 1
                }, null, 'json')
            }
        },

        mobileVer: {
            post: function(code) {
                return $.post(url.verifyMobile(), {
                    serial: code,
                    in_ajax: 1
                }, null, 'json')
            }
        },

        mobileExist: {
            post: function(mobile) {
                return $.post(url.isMobileExist(), {
                    mobile: mobile,
                    in_ajax: 1
                }, null, 'json')
            }
        },

        usernameExist: {
            post: function(username) {
                return $.post(url.isUsernameExist(), {
                    username: username,
                    in_ajax: "1"
                }, null, 'json')
            }
        },

        verImage: {
            get: function() {
                return $.get(url.getCodeImage())
            }
        }
    }
}
