/**
 * js/store/register.js
 */
"use strict"

var dispatcher = require('../dispatcher/ChatAppDispatcher');
var BackboneEvents = window.Backbone.Events;


/**
 * Eventtriggerter
 * @type {[type]}
 */
var assign = require('object-assign')

/**
 * register store
 * @type {[type]}
 */
var store = assign({}, BackboneEvents, {
    events: {
        register: "registerSuccess",
        username: {
            exist: {
                yes: "usernameExist",
                no: "usernameNotExist"
            }
        },

        mobile: {
            exist: {
                yes: "mobileExist",
                no: "mobileNotExist"
            },

            verified: {
                yes: "mobileVerified",
                no: "mobileNotVerified"
            }
        }
    },

    status: "mobileUnchecked"

})

var token = dispatcher.register(function(payload) {
    if (payload.action == "register") {
        store.trigger(store.events.register)
    } else if (payload.action == "isMobileExist") {
        store.status = payload.msg
        if (store.status == 'mobileNotExist') {
            store.trigger(store.events.mobile.exist.no)
        } else {
            store.trigger(store.events.mobile.exist.yes)
        }
    } else if (payload.action == "isUsernameExist") {
        store.status = payload.msg
        if (store.status == 'usernameNotExist') {
            console.log('hhh')
            store.trigger(store.events.username.exist.no)
        } else {
            store.trigger(store.events.username.exist.yes)
        }
    } else if (payload.action == "verifyMobile") {
        store.status = payload.msg
        if (store.status == 'mobileVerified') {
            store.trigger(store.events.mobile.verified.yes)
        } else {
            store.trigger(store.events.mobile.verified.no)
        }
    } else {
        console.log("invalid payload")
    }
})

module.exports = store
